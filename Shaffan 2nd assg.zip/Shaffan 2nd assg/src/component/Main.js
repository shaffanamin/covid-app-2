import React, { useState, useEffect } from 'react';
import Table from 'react-bootstrap/Table';
import axios from 'axios';

export default function Main() {


    const [data1, setData] = useState([])


    const apiHandle = axios.create({
        baseURL: "https://api.covidtracking.com/v1/states",
    });




    const getData = () => {
        apiHandle.get("/current.json").then((e) => {
            setData(e.data)
            console.log(e.data);
        });
    }

    useEffect(() => {
        getData()
    }, [])

    return (
        <div>
            <div>

                <Container>
                    <Table striped bordered hover variant="dark">
                        <thead>
                            <tr>
                                <th>#</th>
                                <th>Date</th>
                                <th>State</th>
                                <th>Positive</th>
                                <th>Negative</th>
                                <th>Death</th>
                            </tr>
                        </thead>
                        {
                            data1.map((e, index) => {
                                return (
                                    <tbody>
                                        <tr key={index}>
                                            <td>{index + 1}</td>
                                            <td>
                                                {/* <a onClick={sendDate}>{data1[index].date}</a> */}
                                                <div className="navbar-brand">
                                                        {e.date}
                                                </div>
                                            </td>
                                            <td>{e.state}</td>
                                            <td>{e.positive}</td>
                                            <td>{e.negative}</td>
                                            <td>{e.death}</td>
                                        </tr>
                                    </tbody>
                                )
                            })

                        }
                    </Table>
                </Container>
            </div>
        </div>
    )
}
