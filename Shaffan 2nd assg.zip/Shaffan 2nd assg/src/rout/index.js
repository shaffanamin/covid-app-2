import Main from "../component/Main";

export { Main } 