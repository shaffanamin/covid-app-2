import 'bootstrap/dist/css/bootstrap.min.css';
import './App.css';
import AppRouter from './rout/rout';

function App() {
  return (
    <div className="App">

    <AppRouter />

    </div>
  );
}

export default App;
